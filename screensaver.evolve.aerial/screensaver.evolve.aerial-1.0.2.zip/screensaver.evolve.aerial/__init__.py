import xbmc

if __name__ == '__main__':
    xbmc.executebuiltin("RunScript(screensaver.evolve.aerial)")
