import ast, random, sys, time, xbmc, xbmcaddon, xbmcgui
from fetcher import get_Videos as gV
from threading import Thread as t
addon = xbmcaddon.Addon()
monitor = xbmc.Monitor()
playlist = xbmc.PlayList(1)
player = xbmc.Player()
videolist = gV().stream_playlist()
path = addon.getAddonInfo("path").decode("utf-8")

home = xbmcgui.Window(10000)
def log(msg):
    xbmc.log("{}".format(msg))
class Start:
    def __init__(self):
        # self.id = xbmcgui.getCurrentWindowId()
        self.playlist = xbmc.PlayList(1)
        self.playlist.clear()
        self.videolist = self.getPlaylist()
        for video in self.videolist[random.randint(0, int(len(self.videolist) - 1))]:
            listitem = xbmcgui.ListItem("%s" % video.get("id"))
            listitem.setInfo( 'video', {
                        'plot': "{}".format(video.get("poi")),
                        'tagline' : "{}".format(video.get("timeOfDay")),
                        'title' : "{}".format(video.get('location'))
                        })
            self.playlist.add(video.get("url"), listitem=listitem)
        self.playlist.shuffle()
        self.background = VideoWindow('evolve_screensaver.xml', path, 'default', '1080i', playlist=self.playlist)
        self.background.doModal()
        del self.background

    def getPlaylist(self):
        return gV().stream_playlist()

class Player(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self, xbmc.Player())
    def OnAVChange(self):
        pass

    def onAVStarted(self):
        xbmc.executebuiltin("PlayerControl(RepeatAll)")
        player.seekTime(0)

    def onPlayBackStopped(self):
        xbmc.executebuiltin("PlayerControl(RepeatOff)")
        self.stop()

class VideoWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self.playlist = kwargs['playlist']
        self.player = Player()
        self.overlay = OverlayWindow('evolve_dialog.xml', path, 'default', '1080i', window=self)

    def onInit(self):
        self.player.play(playlist, windowed=True)
        self.overlay.doModal()
        if self.overlay.started == False:
            self.close()
        del self.overlay

class OverlayWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.player = Player()
        self.background = kwargs["window"]
        self.started = True
        self.poi = None
        self.timeOfDay = None
        self.location = None

    def onInit(self):
        self.label = self.getControl(51)
        self.label.setVisible(False)
        while self.started:
            xbmc.sleep(1000)
            # if monitor.waitForAbort(1):
                # break

            if player.isPlaying():
                self.t = int(player.getTime())
                self.T = int(player.getTotalTime())
                self.Et = self.T-10
                self.data_allocation()

    def data_allocation(self):
        try:
            info = player.getVideoInfoTag()
            new_location = info.getTitle()
            new_poi = ast.literal_eval(info.getPlot())
            if self.location != new_location and self.poi != new_poi:
                self.timeOfDay = info.getTagLine()
                self.location = new_location
        except Exception as err:
            log(err)
        try:
            if self.poi != new_poi:
                self.poi = new_poi
                self.key_list = list()
                for i in sorted(self.poi.iterkeys(), key=int):
                    self.key_list.append(i)
            if self.key_list != "":
                # log(self.key_list)
                # log(self.key_list[0])
                if int(self.t) > int(self.key_list[0]):
                    self.label.setLabel(self.poi["%s" % self.key_list[0]])
                    self.label.setVisible(True)
                if int(self.key_list[0])+10 < int(self.t):
                    del self.key_list[0]
                    self.label.setVisible(False)
        except Exception as err:
            log(err)
            try:
                if self.poi == "" or self.poi == None:
                    self.label.setLabel(self.location)
            except:
                pass
        return

    def counter(self):
        for i in range(10):
            self.label.setVisible(True)
            xbmc.sleep(1000)
        self.label.setVisible(False)


    def onAction(self, action):
        log("ACTION: %s" % action.getId())
        if action == 10 or action == 92:
            self.started = False
            self.player.stop()
            self.close()
        elif action == 100 or action == 103 or action == 7:
            c = t(target=self.counter)
            c.start()
        elif action == 1:
            self.player.playprevious()
        elif action == 2:
            self.player.playnext()



if __name__ == '__main__': Start()
