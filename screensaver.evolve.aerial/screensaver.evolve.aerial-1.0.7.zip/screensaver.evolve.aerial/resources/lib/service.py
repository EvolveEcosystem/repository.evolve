import common as c, local_videos, json, xbmc
monitor = xbmc.Monitor()
localize = local_videos.Downloader(mode=2)

if __name__ == '__main__':

    while not monitor.abortRequested():
        if c.download_folder:
            try:
                data = json.load(open(c.last_updated))
                day = data.get("day")
                week = data.get("week")
                month = data.get("month")
            except:
                day = 0
                week = 0
                month = 0
            if "Daily" in c.download_time:
                d = c.time()['day']
                if int(day) < d or (int(day)>28 and d == 1):
                    localize.download()
            if "Week" in c.download_time:
                w = c.time()['week']
                if int(week) < w:
                    localize.download()
            if "Month" in c.download_time:
                m = c.time()['month']
                if int(month) < m:
                    localize.download()
    # Sleep/wait for abort for 10 seconds
        if monitor.waitForAbort(3600):
            # Abort was requested while waiting. We should exit
            break
