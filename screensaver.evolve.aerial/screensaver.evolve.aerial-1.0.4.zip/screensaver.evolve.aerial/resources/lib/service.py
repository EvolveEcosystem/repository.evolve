import common as c, datetime, local_videos, json, xbmc
monitor = xbmc.Monitor()
localize = local_videos.Downloader(mode=1)

if __name__ == '__main__':
    def update_date(d, w, m):
        data = {
                "day": d,
                "week": w,
                "month": m
                    }
        with open(c.last_updated, "w") as dump:
            json.dump(data, dump)
    while not monitor.abortRequested():
        t = datetime.datetime.today()
        d = t.day
        m = t.month
        w = t.isocalendar()[1]
        try:
            data = json.load(open(c.last_updated))
            day = data.get("day")
            week = data.get("week")
            month = data.get("month")
        except:
            day = 0
            week = 0
            month = 0
        if "Daily" in c.download_time:
            if int(day) < d or (int(day)>28 and d == 1):
                localize.download()
                update_date(d, w, m)
        if "Week" in c.download_time:
            if int(week) < w:
                localize.download()
                update_date(d, w, m)
        if "Month" in c.download_time:
            if int(month) < m:
                localize.download()
                update_date(d, w, m)
    # Sleep/wait for abort for 10 seconds
        if monitor.waitForAbort(3600):
            # Abort was requested while waiting. We should exit
            break
