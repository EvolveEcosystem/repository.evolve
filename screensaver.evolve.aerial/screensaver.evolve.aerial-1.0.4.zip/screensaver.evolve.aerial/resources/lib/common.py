import json, os, xbmc, xbmcaddon, xbmcgui

#set true global variables
addon = xbmcaddon.Addon()
path = addon.getAddonInfo("path").decode("utf-8")
cwd = os.path.dirname(__file__)
dialog = xbmcgui.Dialog()
time_of_day = addon.getSetting("time_of_day").lower()
download_time = addon.getSetting("download_time")
download_folder = addon.getSetting("download_folder")
download_quality = addon.getSetting("download_quality")
china_select = addon.getSetting("china_select")
dubai_select = addon.getSetting("dubai_select")
greenland_select = addon.getSetting("greenland_select")
hawaii_select = addon.getSetting("hawaii_select")
hong_kong_select = addon.getSetting("hong_kong_select")
iss_select = addon.getSetting("iss_select")
liwa_select = addon.getSetting("liwa_select")
london_select = addon.getSetting("london_select")
la_select = addon.getSetting("la_select")
ny_select = addon.getSetting("ny_select")
san_fran_select = addon.getSetting("san_fran_select")
custom_select = addon.getSetting("custom_select")
heading="Evolve: Aerial Screensavers"
name = addon.getAddonInfo("name")
update = os.path.join(addon.getAddonInfo("profile"), "update.json")
last_updated = xbmc.translatePath(update)
aerial_data = json.load(open(os.path.join(cwd,"aerial.json")))
string_data = json.load(open(os.path.join(cwd, "aerial_strings.json")))
excludes = ".(jpg|png|idx|srt|sfnfo|nfo|sub|db|txt|gif|xml)"

#def logs to kodi log
def log(msg):
    xbmc.log("{}".format(msg))

#def creates a notifcation in kodi
def notifcation(msg, heading="Evolve: Aerial Screensavers", time=5000):
    dialog.notification(heading, "{}".format(msg), icon="", time=time)

#def creates a ok dialog in kodi
def ok(msg, heading="Evolve: Aerial Screensavers"):
    dialog.ok(heading,"{}".format(msg))

#def sends info to kodi debug log
def debug(msg):
    xbmc.log(msg, xbmc.LOGDEBUG)

#def creates a list of user selected location to use.
def get_enabled():
    locations = list()
    if custom_select == "true":
        locations.append("My Videos")
    if china_select == "true":
        locations.append("China")
    if dubai_select == "true":
        locations.append("Dubai")
    if greenland_select == "true":
        locations.append("Greenland")
    if hawaii_select == "true":
        locations.append("Hawaii")
    if hong_kong_select == "true":
        locations.append("Hong Kong")
    if iss_select == "true":
        locations.append("International Space Station")
    if liwa_select == "true":
        locations.append("Liwa")
    if london_select == "true":
        locations.append("London")
    if la_select == "true":
        locations.append("Los Angeles")
    if ny_select == "true":
        locations.append("New York")
    if san_fran_select == "true":
        locations.append("San Francisco")
    return locations

#set the user perferred video quality
def get_quality():
    quality_download = list()
    if download_time == "Never":
        quality_download.append("Stream")
    elif download_quality == "HD":
        quality_download.append("HD")
    elif download_quality == "4K":
        quality_download.append("4K")
    elif download_quality == "Both":
        quality_download.append("HD")
        quality_download.append("4K")
    return quality_download

#def creates a list of downloaded videos
def get_local():
    locations = list()
    if download_folder != "":
        try:
            for location in os.listdir(download_folder):
                locations.append(location)
        except Exception as err:
            pass
    return locations
