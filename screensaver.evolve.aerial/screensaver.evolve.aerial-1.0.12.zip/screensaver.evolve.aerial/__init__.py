import xbmc
from resources.lib import common as c


if __name__ == '__main__':
    xbmc.executebuiltin("RunScript(screensaver.evolve.aerial, auto)")
