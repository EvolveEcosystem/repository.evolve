import json, os, time

cwd = os.path.dirname(__file__)
aerial_data = json.load(open(os.path.join(cwd,"aerial.json")))
PATH = r"D:\Apple TV Screensavers"
count = 1

# video_ids = list()
# for i in os.listdir(PATH):
#     loc = os.path.join(PATH, i)
#     for i in os.listdir(loc):
#         q = os.path.join(loc, i)
#         for i in os.listdir(q):
#             video_ids.append(i.split(".")[0])
#
# for location in sorted(aerial_data.keys()):
#     for video in aerial_data[location]["videos"]:
#         id = video["id"]
#         if id in video_ids:
#             print("#{} Got it".format(count))
#             count+=1
#         else:
#             print("MISSING {}".format(id))
hr = time.localtime().tm_hour
min= time.localtime().tm_min
hr+=round(float(min)/60,1)
print(hr)
print(time.localtime().tm_isdst)
