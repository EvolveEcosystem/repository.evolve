import os, json, unicodedata

PATH = os.path.dirname(__file__)
strings = os.path.join(PATH, "common")
ne = os.path.join(PATH, "aerial_strings.json")
oe = os.path.join(PATH, "aerial_strings_old.json")
f = open(strings, 'rb').readlines()
o = open(oe)
d=open(ne, "w")
data = json.load(o)
chars_to_remove = ['";', '"']
for i in f:
    try:
        string = i.strip().decode('utf-8','ignore')
        string = string.replace("\u2019", "'").replace("\xa0", " ").replace("\u2018", "'")
        for i in chars_to_remove:
            string = string.replace(i, "")
        if "=" in string:
            string = string.split(" = ")
            print(string[0])
            print(string[1])
            data.update({string[0]:string[1]})
    except Exception as err:
        print(err)

print("{}".format(data))

d.write(json.dumps(data,indent=4, sort_keys=True))
