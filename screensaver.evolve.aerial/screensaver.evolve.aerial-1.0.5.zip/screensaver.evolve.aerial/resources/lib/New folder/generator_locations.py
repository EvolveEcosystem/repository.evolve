import os, json

PATH = os.path.dirname(__file__)
entry = os.path.join(PATH, "entries.json")
ne = os.path.join(PATH, "new.json")
f = open(entry, 'r')
d=open(ne, "w")
entries = json.load(f)
Data = {}
for i in entries["assets"]:
    try:
        videos = Data[i.get("accessibilityLabel")]["videos"]
        print("HERE")
        new_Data = {
            "id": i.get("id"),
            "iss": "",
            "sea": "",
            "pointsOfInterest": i.get("pointsOfInterest"),
            "timeOfDay": "",
            "url":"",
            "url-1080-H264": i.get("url-1080-H264").replace("https","http"),
            "url-1080-HDR": i.get("url-1080-HDR").replace("https","http"),
            "url-1080-SDR": i.get("url-1080-SDR").replace("https","http"),
            "url-4K-HDR": i.get("url-4K-HDR").replace("https","http"),
            "url-4K-SDR": i.get("url-4K-SDR").replace("https","http")
                    }
        videos.append(new_Data)
        new_Data = {
                        i.get("accessibilityLabel"): {
                            "videos": [videos]
                                                    }
                    }
    except:
        new_Data = {
                        i.get("accessibilityLabel"): {
                            "videos": [{
                                "id": i.get("id"),
                                "iss": "",
                                "sea": "",
                                "pointsOfInterest": i.get("pointsOfInterest"),
                                "timeOfDay": "",
                                "url":"",
                                "url-1080-H264": i.get("url-1080-H264").replace("https","http"),
                                "url-1080-HDR": i.get("url-1080-HDR").replace("https","http"),
                                "url-1080-SDR": i.get("url-1080-SDR").replace("https","http"),
                                "url-4K-HDR": i.get("url-4K-HDR").replace("https","http"),
                                "url-4K-SDR": i.get("url-4K-SDR").replace("https","http")
                                        }]
                                                    }
                    }
        print(new_Data)
        Data.update(new_Data)
d.write(json.dumps(Data,indent=4, sort_keys=True))

'''{
    "Seals": {
        "videos": [
            {
                "id": "83C65C90-270C-4490-9C69-F51FE03D7F06",
                "iss": "False",
                "sea": "True",
                "pointsOfInterest": {
                    "0": "A016_C009_0"
                },
                "timeOfDay": "day",
                "url": "",
                "url-1080-H264": "http://sylvan.apple.com/Videos/SE_A016_C009_SDR_20190717_SDR_2K_AVC.mov",
                "url-1080-HDR": "http://sylvan.apple.com/Aerials/2x/Videos/SE_A016_C009_HDR_20190717_HDR_2K_HEVC.mov",
                "url-1080-SDR": "http://sylvan.apple.com/Aerials/2x/Videos/SE_A016_C009_SDR_20190717_SDR_2K_HEVC.mov",
                "url-4K-HDR": "http://sylvan.apple.com/Aerials/2x/Videos/SE_A016_C009_HDR_20190717_HDR_4K_HEVC.mov",
                "url-4K-SDR": "http://sylvan.apple.com/Aerials/2x/Videos/SE_A016_C009_SDR_20190717_SDR_4K_HEVC.mov"
            }
        ]
    }
}'''
