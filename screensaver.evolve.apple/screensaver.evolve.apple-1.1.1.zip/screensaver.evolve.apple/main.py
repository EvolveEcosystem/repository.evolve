"""
Copyright (C) 2019

This file is part of Evolve Ecosystem.
Evolve Ecosystem is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Evolve Ecosystem is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Evolve Ecosystem.  If not, see <http://www.gnu.org/licenses/>.

@author: smitchell6879
@license: GPL-3.0
"""

from resources.lib.vars import *


class Main:
    def __init__(self, *args, **kwargs):
        self.C = Config()
        self.LOG = EvolveLogger(self.C)
        self.LOG.info("Intializing App")
        self.BACKGROUND = VideoWindow('evolve.videowindow.xml', PATH, 'default', '1080i', log=self.LOG)
        if 'run' in args:
            self.run()
        elif 'save' in args:
            if len(args)>1:
                mode=args[1]
            else:
                mode="visible"
            self.LOG.debug("DOWNLOAD_MODE: %s" % mode)
            LocalizeVideos(log=self.LOG).download(mode)
            self.exit()

    def exit(self):
        self.LOG.close()
    def run(self):
        if PLAYER.isPlayingAudio():
            self.LOG.debug("Audio is playing.")
            if "0" in self.AUDIO:
                self.LOG.debug("AUDIO_SETTING: Stopping Audio")
                PLAYER.stop()
                sleep(1)
                self.launch()
            elif "1" in self.AUDIO:
                self.LOG.debug("AUDIO_SETTING: Keep Audio")
                self.exit()
                return
            else:
                self.LOG.debug("AUDIO_SETTING: Waiting for Audio to end.")
                while not MONITOR.abortRequested():
                    if not PLAYER.isPlayingAudio():
                        self.LOG.debug("Audio finished. Starting App")
                        self.launch()
                    if MONITOR.waitForAbort(5):
                        self.exit()
                        return
        else:
            self.launch()
        self.exit()
    def launch(self):
        self.BACKGROUND.doModal()
        del self.BACKGROUND
class OverlayWindow(xbmcgui.WindowXMLDialog):
    #Overlay Window
    def __init__(self, *args, **kwargs):
        self.LOG = kwargs["log"]
        self.PLAYLIST = kwargs["playlist"]
        self.PLAYERPLAYS = ""
        self.TASK1 = T.Thread(target=self.showInfo)
        #following Vars are a interlock for label
        self.SHOWINGDATA = False
        self.ASHOWINGDATA = False
        self.PLAYING = True
    def onAction(self, action):
        if action == 10 or action == 92:
            self.exit()
        elif action == 100 or action == 103 or action == 7:
            #Onclick Action Shows Data
            if not self.ASHOWINGDATA:
                self.ASHOWINGDATA = True
                for i in range(5):
                    if not self.label.isVisible():
                        self.label.setVisible(True)
                    sleep(1)
                self.ASHOWINGDATA = False
            if not self.SHOWINGDATA and not self.ASHOWINGDATA:
                self.label.setVisible(False)
        elif action == 1:
            self.PLAYERPLAYS = False
            self.label.setLabel("")
            self.label.setVisible(False)
            sleep(1)
            if int(self.PLAYLIST.size()) == (int(self.PLAYLIST.getposition())+1):
                PLAYER.pause()
                PLAYER.play(self.PLAYLIST, windowed=True)
            else:
                PLAYER.playprevious()

        elif action == 2:
            self.PLAYERPLAYS = False
            self.label.setLabel("")
            self.label.setVisible(False)
            sleep(1)
            if int(self.PLAYLIST.size()) == (int(self.PLAYLIST.getposition())+1):
                PLAYER.pause()
                PLAYER.play(self.PLAYLIST, windowed=True)
            else:
                PLAYER.playnext()
    def onInit(self):
        self.LOG.debug("Initialzed Overlay Window")
        self.AUTOSHOW = ADDON.getSetting("genDcL")
        self.label = self.getControl(51)
        self.label.setVisible(False)
        self.getVideoData()
    def exit(self):
        self.PLAYERPLAYS = False
        self.PLAYING = False
        self.LOG.debug("Closing Overlay Window")
        self.close()
    def showInfo(self):
        lastKEY = ""
        debugInfo = "Set Location Information."
        while self.PLAYING:
            try:
                self.time = PLAYER.getTime()
                if self.POI is None:
                    self.label.setLabel(self.LOCATION)
                else:
                    if len(self.KEYS)>=1:
                        key = self.KEYS[0]
                        if key != lastKEY:
                            if int(self.time) >= int(key):
                                info = STRINGS[self.POI[self.KEYS[0]]]
                                lastKEY=self.KEYS[0]
                                self.label.setLabel(label(int(info)))
                                if self.AUTOSHOW == "true":
                                    self.label.setVisible(True)
                                    self.SHOWINGDATA = True
                                self.LOG.debug(debugInfo)
                                if "Set" in debugInfo:
                                    debugInfo = "Updated Location Information."
                                # self.LOG.debug(label(int(info)))
                                # self.LOG.debug(key)
                                # self.LOG.debug(self.time)
                                del self.KEYS[0]
                                sleep(5)
                                if not self.ASHOWINGDATA:
                                    self.label.setVisible(False)
                                self.SHOWINGDATA = False
                        else:
                            if self.OLDFILE != PLAYER.getPlayingFile():
                                self.OLDFILE = PLAYER.getPlayingFile()
                                lastKEY = None
                            sleep(1)
            except Exception as err:
                print(err)
    def getVideoData(self):
        self.TASK1.start()
        self.OLDFILE=""
        while self.PLAYING:
            if PLAYER.isPlayingVideo():
                if self.OLDFILE != PLAYER.getPlayingFile():
                    self.PLAYERPLAYS = True
                    info = PLAYER.getVideoInfoTag()
                    self.KEYS = list()
                    self.LOCATION = info.getTitle()
                    self.POI = ast.literal_eval(info.getPlot())
                    self.TIMEOFDAY = info.getTagLine()
                    self.LOG.debug("FOLDER: %s" % self.LOCATION)
                    self.LOG.debug("ID: %s" % info.getOriginalTitle())
                    self.LOG.debug("SOURCE: %s" % info.getPath())
                    if not self.POI is None:
                        try:
                            for k in sorted(self.POI.iterkeys(), key=int):
                                self.KEYS.append(k)
                        except:
                            for k in sorted(self.POI.keys(), key=int):
                                self.KEYS.append(k)
                        self.KEYS.sort(key=int)
                    # self.LOG.debug("%s" % self.KEYS)
                    # self.LOG.debug("%s" % self.LOCATION)
                    # self.LOG.debug("%s" % self.POI)
                    # self.LOG.debug("%s" % self.TIMEOFDAY)
                    self.LOG.debug("Got Video Data")
                    self.OLDFILE = PLAYER.getPlayingFile()
            sleep(1)
class VideoPlaylist:
    def __init__(self, *args, **kwargs):
        self.LOG = kwargs["log"]
        self.LOCATIONS = list()
        self.VIDEOS = list()
        self.STREAMING = False
        if ADDON.getSetting("cSelected") == "true":
            self.LOCATIONS.append("China")
        if ADDON.getSetting("dSelected") == "true":
            self.LOCATIONS.append("Dubai")
        if ADDON.getSetting("gSelected") == "true":
            self.LOCATIONS.append("Greenland")
        if ADDON.getSetting("hSelected") == "true":
            self.LOCATIONS.append("Hawaii")
        if ADDON.getSetting("hkSelected") == "true":
            self.LOCATIONS.append("Hong Kong")
        if ADDON.getSetting("issSelected") == "true":
            self.LOCATIONS.append("iss")
        if ADDON.getSetting("lSelected") == "true":
            self.LOCATIONS.append("Liwa")
        if ADDON.getSetting("loSelected") == "true":
            self.LOCATIONS.append("London")
        if ADDON.getSetting("laSelected") == "true":
            self.LOCATIONS.append("Los Angeles")
        if ADDON.getSetting("nSelected") == "true":
            self.LOCATIONS.append("New York")
        if ADDON.getSetting("sSelected") == "true":
            self.LOCATIONS.append("San Francisco")
        if ADDON.getSetting("uSelected") == "true":
            self.LOCATIONS.append("sea")
        try:
            self.DOWNLOADING = kwargs["download"]
        except:
            self.DOWNLOADING = False
        if ADDON.getSetting("stream") == "true":
            #0 = HD, 1=4K, 2=Both
            self.LOG.debug("Will Create a Streaming Playlist")
            self.QUALITY = ADDON.getSetting("streamQ")
            self.STREAMING = True
        elif self.DOWNLOADING:
            self.LOG.debug("Will Create a Downloadlist")
            self.QUALITY = ADDON.getSetting("dlQ")
        else:
            self.LOG.debug("Will Create a Local Playlist")
            self.QUALITY = ADDON.getSetting("localQ")
            self.LOCATION = ADDON.getSetting("dlFolder")
        self.LOG.debug("Video Quality is %s" % self.QUALITY)
    def getVideos(self):
        # Adds all enabled videos to the videolist.
        def setTime():
            # Sets the time of day.
            # Note: 0 = All, 1=Auto, 2=Day, 3=Night
            TOD = ADDON.getSetting("genTod")
            if "0" in TOD:
                self.TOD = "all"
            elif "1" in TOD:
                hr = time.localtime().tm_hour
                min = time.localtime().tm_min
                hr+=round(float(min)/60,1)
                # dst = bool(time.localtime().tm_isdst)
                # if dst:
                #     hr+=1
                if (hr > 5.5) and (hr < 17.5):
                    self.TOD = "day"
                else:
                     self.TOD = "night"
            elif "2" in TOD:
                self.TOD = "day"
            else:
                self.TOD = "night"
        def appendVideo(video, url, quality):
            data = {
                    'originaltitle': "{}".format(video.get("id")),
                    'path': url,
                    'plot': "{}".format(video.get("pointsOfInterest")),
                    'tag': quality,
                    'tagline' : "{}".format(video.get("timeOfDay")),
                    'title' : "{}".format(video.get('location')),
                    'sorttitle': "{}".format(video.get('folder'))
                    }
            if self.DOWNLOADING or ADDON.getSetting('stream') == "true":
                self.VIDEOS.append(data)
            else:
                if exists(url):
                    # self.LOG.debug("VIDEOADDED: %s" % url)
                    self.VIDEOS.append(data)
        def getUrl(video):
            if self.DOWNLOADING or ADDON.getSetting('stream') == "true":
                if "0" in ADDON.getSetting('genFmt'):
                    url = video.get("url-1080-SDR")
                else:
                    url = video.get("url-1080-H264")

                if url == "" or url == None:
                    url = video.get("url")
                url4KH = video.get("url-4K-HDR")
                url4K = video.get("url-4K-SDR")
                urlHDR = video.get("url-1080-HDR")
                urlSDR = video.get("url-1080-SDR")
            else:
                url = os.path.join(self.LOCATION, video.get('folder'),"HD", "%s.mov" % video.get("id"))
                url4K = os.path.join(self.LOCATION,video.get('folder'), "4K", "%s.mov" % video.get("id"))
                url4KH = ""
                urlHDR = ""
                urlSDR = ""
            # c.debug(url)
            # c.debug(url4K)

            if url4K != "" and url4K != None:
                if "1" in self.QUALITY or "2" in self.QUALITY or "3" in self.QUALITY:
                    appendVideo(video, url4K, "4K")
            if url4KH != "" and url4KH != None:
                if "4" in self.QUALITY:
                    appendVideo(video, url4KH, "4K_HDR")
            if urlHDR != "" and urlHDR != None:
                if "4" in self.QUALITY:
                    appendVideo(video, urlHDR, "HD_HDR")
            if urlSDR != "" and urlSDR != None:
                if "4" in self.QUALITY:
                    appendVideo(video, urlSDR, "HD_SDR")
                if self.DOWNLOADING:
                    url = urlSDR
            if url != "" and url != None:
                if "0" in self.QUALITY or "2" in self.QUALITY or "3" in self.QUALITY:
                    appendVideo(video, url, "HD")
        def filterTime(video):
            # Appends videos to videolist.
            if "all"  in self.TOD:
                getUrl(video)
            else:
                if self.TOD in video["timeOfDay"]:
                    getUrl(video)
        def specialVideos(special):
            # Gets only specail videos form source
            for entry in sorted(ENTRY.keys()):
                for video in ENTRY[entry]["videos"]:
                    if "sea" in special:
                        folder = label(30310)
                    elif "iss" in special:
                        folder = label(30304)
                    video.update({"location": entry, "folder": folder})
                    if "True" in video[special]:
                        if not video in self.VIDEOS:
                            # c.debug("%s: %s: %s: %s" % (self.TOD, location.rjust(6), entry.rjust(35), video["id"].rjust(38)))
                            filterTime(video)
        setTime()
        for location in self.LOCATIONS:
            if not location in ENTRY.keys():
                specialVideos(location)
            else:
                for video in ENTRY[location]["videos"]:
                    video.update({"location": location, "folder": location})
                    if video["iss"] == "False" and video["sea"] == "False":
                        if not video in self.VIDEOS:
                            # c.debug("%s: aerial: %s: %s" % (self.TOD, location.rjust(35), video["id"].rjust(38)))
                            filterTime(video)
        return self.VIDEOS
    def getPlaylist(self):
        self.PLAYLIST = xbmc.PlayList(1)
        self.PLAYLIST.clear()
        self.getVideos()
        global VIDEOLISTLEN
        VIDEOLISTLEN = len(self.VIDEOS)
        self.LOG.debug("PLAYLIST_LENGHT: %s" % VIDEOLISTLEN)
        if VIDEOLISTLEN == 0:
            self.LOG.error("FILE: main.py|CLASS: VideoPlaylist|DEF: getPlaylist|ERROR: VIDEO_LIST_LENGTH_FAILED")
            if self.STREAMING:
                ok("{}{}\"{}\"{}\"{}\"{}".format(label(30366), label(30353),self.TOD.title(), label(30354),self.TOD,label(30355)))
            else:
                ok("{}{}\"{}\"{}\"{}\"{}".format(label(30367), label(30353),self.TOD.title(), label(30354),self.TOD,label(30368)))
            return None
        else:
            payload = {
                        "Connection": "keep-alive",
                        "Upgrade": "",
                        "HTTP2-Settings": ""
                      }
            # "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36",
            for n in range(50):
                #Shuffle Videos.
                random.shuffle(self.VIDEOS)
            for video in self.VIDEOS:
                #Add videos to playlist
                listitem = xbmcgui.ListItem("%s" % (video["originaltitle"]))
                listitem.setInfo('video', video)
                url = video.get("path")
                if self.STREAMING:
                    listitem.setMimeType("video/quicktime")
                    # url = "{}|{}".format(url, c.encodeUrl(payload))
                    url = "{}".format(url)
                self.PLAYLIST.add(url, listitem=listitem)
            return self.PLAYLIST
    def getPlayingPlaylist(self):
        properties = """{
                "jsonrpc": "2.0",
                "method": "Playlist.GetItems",
                "params":
                    { "properties":[
                                      "title",
                                      "artist",
                                      "albumartist",
                                      "genre",
                                      "year",
                                      "rating",
                                      "album",
                                      "track",
                                      "duration",
                                      "comment",
                                      "lyrics",
                                      "musicbrainztrackid",
                                      "musicbrainzartistid",
                                      "musicbrainzalbumid",
                                      "musicbrainzalbumartistid",
                                      "playcount",
                                      "fanart",
                                      "director",
                                      "trailer",
                                      "tagline",
                                      "plot",
                                      "plotoutline",
                                      "originaltitle",
                                      "lastplayed",
                                      "writer",
                                      "studio",
                                      "mpaa",
                                      "cast",
                                      "country",
                                      "imdbnumber",
                                      "premiered",
                                      "productioncode",
                                      "runtime",
                                      "set",
                                      "showlink",
                                      "streamdetails",
                                      "top250",
                                      "votes",
                                      "firstaired",
                                      "season",
                                      "episode",
                                      "showtitle",
                                      "thumbnail",
                                      "file",
                                      "resume",
                                      "artistid",
                                      "albumid",
                                      "tvshowid",
                                      "setid",
                                      "watchedepisodes",
                                      "disc",
                                      "tag",
                                      "art",
                                      "genreid",
                                      "displayartist",
                                      "albumartistid",
                                      "description",
                                      "theme",
                                      "mood",
                                      "style",
                                      "albumlabel",
                                      "sorttitle",
                                      "episodeguide",
                                      "uniqueid",
                                      "dateadded",
                                      "channel",
                                      "channeltype",
                                      "hidden",
                                      "locked",
                                      "channelnumber",
                                      "starttime",
                                      "endtime",
                                      "specialsortseason",
                                      "specialsortepisode",
                                      "compilation",
                                      "releasetype",
                                      "albumreleasetype",
                                      "contributors",
                                      "displaycomposer",
                                      "displayconductor",
                                      "displayorchestra",
                                      "displaylyricist",
                                      "userrating"
                                    ],
                      "playlistid": 1
                     },
                "id": 1
                }"""
        return json.loads(xbmc.executeJSONRPC(properties))
    def restorePlayingPlaylist(self, data, cdata):
        self.PLAYLIST = xbmc.PlayList(1)
        self.PLAYLIST.clear()
        for item in data['result']['items']:
            listitem = xbmcgui.ListItem("%s" % i.get("title"))
            listitem.setLabel("{}".format(i.get("title")))
            listitem.setLabel2("{}".format(i.get("year")))
            listitem.setInfo('video', {
                                    "plot": i.get("plot"),
                                    "tagline" :i.get("tagline"),
                                    "title": i.get("title"),
                                    "year": i.get("year")
                                    })
            listitem.setArt({"thumb": i.get("thumbnail")})
            listitem.setPath(path=i.get('file'))
            self.PLAYLIST.add(i.get('file'), listitem=listitem)
            if item.get('title') in c.data['title']:
                listitem.setProperty("Resume", "{}".format(float(int(c.data['time'])-10)))
                listitem.setProperty("Total Time", "{}".format(float(int(c.data["totalTime"]))))
                self.RESUME = listitem
        return self.PLAYLIST, self.RESUME
class VideoWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self.LOG = kwargs["log"]
        self.NOWPLAYING = False
        self.PLAYERPLAYS = False
        self.VIDEO = ADDON.getSetting("genVideo")
    def onAction(self, action):
        if action == 10 or action == 92:
            pass
    def onInit(self):
        self.LOG.debug("Initialzed Video Window")
        self.label = self.getControl(51)
        if PLAYER.isPlayingVideo():
            if "0" in self.VIDEO:
                self.LOG.debug("VIDEO_SETTING: Getting Playlist")
                if bool(xbmc.getCondVisibility("Player.Paused")):
                    self.NOWPLAYING = True
                    self.NPDATA = {
                            "title" : PLAYER.getVideoInfoTag().getTitle(),
                            "time" : PLAYER.getTime(),
                            "totalTime" :  PLAYER.getTotalTime(),
                                }
                    self.NPPLDATA = VideoPlaylist(log=self.LOG).getPlayingPlaylist()
                    self.launch()
                    PLAYLIST, RESUME = VideoPlaylist(log=self.LOG).restorePlayingPlaylist(self.NPPLDATA, self.NPDATA, log=self.LOG)
                    PLAYER.play(PLAYLIST, listitem=RESUME)
                    sleep(1)
                    PLAYER.pause()
                    while self.NOWPLAYING:
                        if PLAYER.isPlayingVideo():
                            PLAYER.seekTime(float(int(self.NPDATA['time'])-10))
                            self.NOWPLAYING = False
                            self.exit()
                        if MONITOR.waitForAbort(.5):
                            return
                    sleep(5)
            return
        else:
            self.launch()
        self.exit()
    def exit(self):
        self.LOG.debug("Closing Video Window.")
        self.close()
    def launch(self):
        self.label.setLabel(label(30349))
        self.LOG.debug("Getting Playlist.")
        sleep(1)
        self.PLAYLIST = VideoPlaylist(log=self.LOG).getPlaylist()
        if self.PLAYLIST == None:
            self.exit()
        self.OVERLAY = OverlayWindow('evolve.dialog.xml', PATH, 'default', '1080i', log=self.LOG, playlist=self.PLAYLIST)
        self.label.setLabel(label(30352))
        sleep(1)
        PLAYER.play(self.PLAYLIST, windowed=True)
        self.LOG.debug("Player Started.")
        while not self.PLAYERPLAYS:
            if PLAYER.isPlayingVideo():
                if not RUNNING:
                    PLAYER.stop()
                    self.exit()
                self.PLAYERPLAYS = True
                self.label.setLabel(" ")
                self.label.setVisible(False)
                self.LOG.debug("Player is playing.")
                self.OVERLAY.doModal()
                del self.OVERLAY
        if PLAYER.isPlayingVideo():
            PLAYER.stop()
            self.LOG.debug("Player Stopped.")
            self.PLAYERPLAYS = False
class LocalizeVideos:
    def __init__(self, *args, **kwargs):
        self.LOG = kwargs["log"]
        self.LOG.info("Starting downloader.")
        self.LOCAL = ADDON.getSetting("dlFolder")
        self.LOG.debug("Download Path: %s" % self.LOCAL)
    def exit(self):
        if 'visible' in self.MODE:
            PROGRESS.close()
    def update(self, precent, txt):
        if 'visible' in self.MODE:
            PROGRESS.update(precent, txt)
    def download(self, mode):
        self.MODE = mode
        if "none" in self.LOCAL.lower():
            ok(label(30372))
            return
        if 'visible' in self.MODE:
            PROGRESS.create(HEADER, "Getting available Screensavers" )
            self.LOG.debug("Getting available Screensavers")
        videos = VideoPlaylist(download=True, log=self.LOG).getVideos()
        vLen = len(videos)
        for video in videos:
            self.getStream(video, vLen)
        self.exit()
    def getStream(self, video, vLen):
        """
        example:
        {
        'originaltitle': '83C65C90-270C-4490-9C69-F51FE03D7F06',
        'plot': "{'0': 'A016_C009_0'}",
        'tagline': 'day',
        'title': 'Seals',
        'sorttitle': 'Under the Sea',
        'path': 'http://sylvan.apple.com/Aerials/2x/Videos/SE_A016_C009_SDR_20190717_SDR_2K_HEVC.mov'
         }"""
        #def converts bytes to best size option
        def format_bytes(bytes):
            sizes = [ "B", "KB", "MB", "GB", "TB" ]
            i = 0
            while (i < len(sizes) and  bytes >= 1024):
                dblbyte = bytes / 1024.0
                i = i + 1
                bytes = bytes / 1024
            return "%.02f %s" % (round(dblbyte, 2), sizes[i])
        chunkSize = 8192
        totalSize = 0
        startTime = time.time()
        vDir = os.path.join(self.LOCAL, video['sorttitle'], video['tag'])
        self.LOG.debug("Checking Path")
        check(vDir)
        vIn = video['path']
        vOut = os.path.join(vDir, "%s.mov" % video['originaltitle'])
        self.LOG.debug(vOut)
        with HTTP.request('GET', vIn, preload_content=False) as r:
            size = r.headers.get("Content-Length")
            vSize = format_bytes(int(size))
            if exists(vOut):
                if int(size) != int(file(vOut).size()):
                    os.remove(vOut)
            if not os.path.isfile(vOut):
                with open(vOut, 'wb') as f:
                    for chunk in r.stream(chunkSize):
                        if chunk:
                            f.write(chunk)
                            totalSize+=chunkSize
                            if 'visible' in self.MODE:
                                percent = min(int(totalSize) * 100 / int(size), 100)
                                fetchedAmount = format_bytes(int(totalSize))
                                speed = int(int(totalSize) / (time.time()-startTime))
                                eta = (int(size) - int(totalSize)) / speed
                                if eta < 60:
                                    eta = "{} secs".format(int(eta))
                                else:
                                    m = round(eta/60)
                                    sec = eta-(60*m)
                                    eta = "{} mins {} secs".format(int(m), int(sec))
                                line0 = "%s: %s %s " % (video['sorttitle'].title(), video['title'].title(), video['tag'])
                                line1 = "Downloading %s of %s" % (fetchedAmount, vSize)
                                line2 = "Remaining Time: %s" % eta
                                PROGRESS.update(int(percent), line0, line1, line2, )
                                if PROGRESS.iscanceled():
                                    f.close()
                                    r.release_conn()
                                    time.sleep(1)
                                    os.remove(vOut)
                                    sys.exit()
                    f.close()
        r.release_conn()


















if __name__ == '__main__':
    if len(sys.argv) >1:
        if 'auto' in sys.argv[1]:
            print("KODIS REQUEST")
        elif 'download' in sys.argv[1]:
            if len(sys.argv)>2:
                if 'mode' in sys.argv[2]:
                    mode = sys.argv[2].split('mode=')[1]
                    Main('save', mode)
            else:
                Main('save')
    else:
        Main('run')
