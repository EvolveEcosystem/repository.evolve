"""
Copyright (C) 2019

This file is part of Evolve Ecosystem.
Evolve Ecosystem is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Evolve Ecosystem is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Evolve Ecosystem.  If not, see <http://www.gnu.org/licenses/>.

@author: smitchell6879
@license: GPL-3.0
"""
import ast, json, logging, os, random, sys, time, threading as T, urllib3
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
from datetime import datetime

ADDON = xbmcaddon.Addon()
CWD = os.path.dirname(__file__)
DIALOG = xbmcgui.Dialog()
HEADER = "Evolve Apple Screensavers"
HOME = xbmcgui.Window(10000)
HTTP = urllib3.PoolManager()
ID = ADDON.getAddonInfo("id")
KPSM = json.loads(xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue","params":{"setting":"powermanagement.displaysoff"},"id":2}'))['result']['value'] * 60
NAME = ADDON.getAddonInfo("name")
VERSION = ADDON.getAddonInfo("version")
MONITOR = xbmc.Monitor()
NOW = datetime.fromtimestamp
PATH = ADDON.getAddonInfo("path")
PROFILE = xbmc.translatePath(ADDON.getAddonInfo("profile"))
PROGRESS = xbmcgui.DialogProgress()
PYVERSION = sys.version.split(".")[0]
RESOURCES = os.path.join(CWD, "..")
RUNNING = True
STRINGS = json.load(open(os.path.join(RESOURCES, "poi.json")))
ENTRY = json.load(open(os.path.join(RESOURCES, "entries.json")))


if "2" in PYVERSION:
    import ConfigParser, urllib
else:
    import configparser as ConfigParser
    from urllib.parse import urlencode, quote_plus
def check(path):
    if not exists(path):
        mkdir(path)
def delete(path):
    return xbmcvfs.delete(path)
def dict_factory(curs, row):
    #returns dictionary of sqlite data
    d = {}
    for idx, col in enumerate(curs.description):
        d[col[0]] = row[idx]
    return d
def exists(path):
    #Kodi Check is file/folder exists
    return xbmcvfs.exists(path)
def file(path, mode=""):
    return xbmcvfs.File(path, mode)
def label(num):
    return ADDON.getLocalizedString(num)
def mkdir(path):
    xbmcvfs.mkdirs(path)
def ok(msg, heading="Evolve: Apple Screensavers"):
    DIALOG.ok(heading,"{}".format(msg))
def pad(w):
    return "_".ljust(int(w)).replace(" ","_")
def random_digits(n):
    #create random digit in len of n
    return random.randint(10**(n-1), (10**n)-1)
def rename(old, new):
    xbmcvfs.rename(old, new)
def sleep(t):
    #Kodi wait for (t)ime
    t = int(float(t)*1000)
    xbmc.sleep(t)
def today():
    #Returns time dictionary
    t = datetime.today()
    data = {
            "day": t.day,
            "week": t.isocalendar()[1],
            "month": t.month
                }
    return data
def encodeUrl(payload):
    try:
        return urlencode(payload, quote_via=quote_plus)
    except:
        return urllib.urlencode(payload)
class Config:
    def __init__(self):
        self.CNFPR = ConfigParser.RawConfigParser()
        self.CONFIG = os.path.join(PROFILE, "evolve.conf")
        if not exists(PROFILE):
            mkdir(PROFILE)
        if not exists(self.CONFIG):
            self.conf_template()
        else:
            self.conf_load()
    def conf_template(self):
        #Create Config file if missing/ first run
        #Headers
        self.CNFPR.add_section("bug-tracking")
        #Settings
        if int(VERSION.split(".")[0]) < 2:
            self.CNFPR.set("bug-tracking", "debug", "True")
        else:
            self.CNFPR.set("bug-tracking", "debug", "False")
        #Write default config
        with open(self.CONFIG, 'w') as f:
            self.CNFPR.write(f)
        sleep(.5)
        #Load config
        self.conf_load()
    def conf_update(self, section, setting, value):
        #Updates Configuration File
        CNFPR.set("{}".format(section), "{}".format(setting), "{}".format(value))
        with open(CONFIG, "w") as f:
            CNFPR.write(f)
        sleep(.5)
    def conf_load(self):
        #Load Configuration
        self.CNFPR.read(self.CONFIG)
        #Set varaibles
        self.DEBUGGING = self.CNFPR.getboolean("bug-tracking", "debug")
class EvolveLogger:
    def __init__(self, c):
        self.LOGGER = logging.getLogger('EvolveLogger')
        self.LOGFILE = os.path.join(PROFILE, 'evolve.log')
        self.OLDLOG = os.path.join(PROFILE, 'evolve.old.log')
        self.DEBUGGING = c.DEBUGGING
        self.clean_logs()
        self.setup()
        self.start()
    def clean_logs(self):
        if exists(self.LOGFILE):
            if exists(self.OLDLOG):
                delete(self.OLDLOG)
                sleep(.1)
            rename(self.LOGFILE, self.LOGFILE.replace(".log",".old.log"))
            sleep(.1)
    def close(self):
        #Close Logger End Script
        self.info("Script is shutting down.")
        LOGHANDLER = logging.FileHandler(self.LOGFILE)
        LOGHANDLER.close()
        self.LOGGER.removeHandler(LOGHANDLER)
        logging.shutdown()
        HOME.clearProperty("evolve.apple.running")
    def critical(self, err, errType="", errStr="", exData="", msg=""):
        #Logs msg to kodi.log and evolve.log
        self.LOGGER.setLevel(logging.CRITICAL)
        xbmc.log("EVOLVE_CRITICAL: {}".format(msg), xbmc.LOGFATAL)
        data = "\n{}{}\n{}Error Type: {}\n{}Error Contents: {}\n{}{}".format(pad,
                                                                             msg,
                                                                             pad(26),
                                                                             errType,
                                                                             pad,
                                                                             errStr,
                                                                             pad(26),
                                                                             exData)
        self.LOGGER.critical(data)
        sleep(1)
        ok(msg)
    def debug(self, msg):
        #Logs msg to kodi.log and evolve.log
        if self.DEBUGGING:
            self.LOGGER.setLevel(logging.DEBUG)
            xbmc.log("EVOLVE_DEBUG: {}".format(msg), xbmc.LOGDEBUG)
            self.LOGGER.debug(msg)
    def error(self, msg):
        #Logs msg to kodi.log and evolve.log
        self.LOGGER.setLevel(logging.ERROR)
        xbmc.log("EVOLVE_ERROR: {}".format(msg), xbmc.LOGERROR)
        self.LOGGER.error(msg)
    def info(self, msg):
        #Logs msg to kodi.log and evolve.log
        self.LOGGER.setLevel(logging.INFO)
        xbmc.log("EVOLVE_INFO: {}".format(msg), xbmc.LOGINFO)
        self.LOGGER.info(msg)
    def setup(self):
        LOGHANDLER = logging.FileHandler(self.LOGFILE)
        f = self.time_format(fmt='%(asctime)s %(levelname)s: %(message)s',datefmt='%Y-%m-%d %H:%M:%S:%f')
        LOGHANDLER.setFormatter(f)
        self.LOGGER.addHandler(LOGHANDLER)
    def start(self):
        #Starts Evolve Logger
        if not "True" in HOME.getProperty("evolve.apple.running"):
            HOME.setProperty("evolve.apple.running", "True")
            #Log System information
            data = ["Busy"]
            while "Busy" in data:
                data = [xbmc.getInfoLabel("System.OSVersionInfo"),
                        xbmc.getInfoLabel("System.BuildVersion"),
                        xbmc.getInfoLabel("System.BuildDate"),
                        xbmc.getInfoLabel("System.InternetState")
                        ]
            self.info(pad(50))
            self.info("Starting Evolve Ecosystem Verison %s" % VERSION)
            self.info("Python Verison: %s" % PYVERSION)
            self.info("OS: %s" % data[0])
            self.info("Kodi: %s" % data[1])
            self.info("Compiled on: %s" % data[2])
            self.info("Internet State: %s" % data[3])
            self.info("DEBUG MODE: %s" % self.DEBUGGING)
            self.info(pad(50))
    def warn(self, msg):
        #Logs msg to kodi.log and evolve.log
        if self.DEBUGGING:
            self.LOGGER.setLevel(logging.WARNING)
            xbmc.log("EVOLVE_WARNING: {}".format(msg), xbmc.LOGWARNING)
            self.LOGGER.warning(msg)
    class time_format(logging.Formatter):
        converter=datetime.fromtimestamp
        def formatTime(self, record, datefmt):
            ct = self.converter(record.created)
            return ct.strftime(datefmt)[:-3]
class Player(xbmc.Player):
    #Player Class Pretty Basic
    def __init__(self):
        xbmc.Player.__init__(self, xbmc.Player())
PLAYER = Player()
AUDIO = ADDON.getSetting("genAudio")
